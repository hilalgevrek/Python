"""
This is module 1. Welcome!
"""

def addition(a, b):
    return a + b

def multi(x, y):
    return x * y