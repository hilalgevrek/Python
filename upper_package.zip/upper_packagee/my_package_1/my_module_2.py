"""
This is module 2. Welcome!
"""

def divide(a, b):
    return (a/b)

def hello():
    print("hello")

