"""
This is module 4. Welcome!
"""

def square(a):
    return (a ** 2)

def sqroot(b):
    return b ** 0.5

