"""
This is module 3. Welcome!
"""

def concat_str(a, b):
    return a + b

def repeater(x, y):
    return x * y